-- създаване на база данни GYM
CREATE DATABASE gym;
USE gym;

-- създаване на таблица Members
create table members
(
members_id int AUTO_INCREMENT primary key,
first_name varchar (100) not null,
last_name varchar (100) not null,
phone_number int UNIQUE,
birth_date date,
gender varchar (10) not null
);
-- вмъкване на записи в Members
INSERT INTO members VALUES
(1, 'Ivan', 'Petrov', 0888111222, '1995-03-12', 'Male'),
(2, 'Maria', 'Ivanova', 0888222333, '1992-07-22', 'Female'),
(3, 'Georgi', 'Dimitrov', 0888333444, '1988-01-10', 'Male'),
(4, 'Elena', 'Koleva', 0888444555, '1997-09-05', 'Female'),
(5, 'Petar', 'Nikolov', 0888555666, '1990-12-18', 'Male'),
(6, 'Viktoria', 'Todorova', 0888666777, '1994-04-30', 'Female'),
(7, 'Martin', 'Stoyanov', 0888777888, '1985-06-14', 'Male'),
(8, 'Nikol', 'Georgieva', 0888888999, '1999-11-25', 'Female'),
(9, 'Dimitar', 'Angelov', 0889111222, '1991-08-09', 'Male'),
(10,'Radoslav', 'Kostov', 0889222333, '1987-02-02', 'Male'),
(11, 'Denislav', 'Hristov', 0883772388, '2007-08-27', 'Male'),
(12, 'Andrea', 'Angelova', 0877377255, '2009-09-19', 'Female'),
(13, 'Aleksandar', 'Ivanov', 0877565780, '2011-08-17', 'Male'),
(14, 'Ema', 'Vasileva', 0899877234, '2008-12-03', 'Female'),
(15, 'Tihomir', 'Petrov', 0899674236, '2001-01-26', 'Male');
-- създаване на таблица Trainers
create table trainers
(
trainer_id int auto_increment primary key,
first_name varchar (100) not null,
last_name varchar (100) not null,
phone_number int UNIQUE
);
-- вмъкване на записи в Trainers
INSERT INTO trainers VALUES
(1, 'Ivan', 'Stanchev', 0887111111),
(2, 'Georgi', 'Marinov', 0887222222),
(3, 'Petya', 'Kirova', 0887333333),
(4, 'Nikolay', 'Dobrev', 0887444444),
(5, 'Stefan', 'Petkov', 0887555555),
(6, 'Daniela', 'Ruseva', 0887666666),
(7, 'Hristo', 'Iliev', 0887777777),
(8, 'Krasimir', 'Angelov', 0887888888),
(9, 'Yana', 'Vasileva', 0887999999),
(10,'Milena', 'Popova', 0886111111);

-- създаване на таблица Workouts
create table workouts
(
workout_id int auto_increment primary key,
name varchar (100) not null,
difficulty_level varchar (100) not null,
trainer_id int not null,
CONSTRAINT fk_trainer
FOREIGN KEY (trainer_id)
REFERENCES trainers(trainer_id)
);
-- вмъкване на записи в Workouts
INSERT INTO workouts VALUES
(1, 'Full Body Beginner', 'Easy', 1),
(2, 'Upper Body Strength', 'Medium', 2),
(3, 'Leg Day', 'Hard', 3),
(4, 'Cardio Blast', 'Easy', 4),
(5, 'Core Workout', 'Medium', 5),
(6, 'HIIT Advanced', 'Hard', 6),
(7, 'Back & Biceps', 'Medium', 7),
(8, 'Chest & Triceps', 'Medium', 8),
(9, 'Morning Stretch', 'Easy', 9),
(10,'Strength Pro', 'Hard', 10);

-- създаване на таблица Exercises
create table exercises
(
exercise_id int auto_increment primary key,
name varchar (100) not null,
muscle_group varchar (100) not null,
equipment varchar (100) not null
);
-- вмъкване на записи в Exercises
INSERT INTO exercises VALUES
(1, 'Push Ups', 'Chest', 'None'),
(2, 'Squats', 'Legs', 'None'),
(3, 'Deadlift', 'Back', 'Barbell'),
(4, 'Plank', 'Core', 'Mat'),
(5, 'Bench Press', 'Chest', 'Barbell'),
(6, 'Pull Ups', 'Back', 'Bar'),
(7, 'Lunges', 'Legs', 'Dumbbells'),
(8, 'Shoulder Press', 'Shoulders', 'Dumbbells'),
(9, 'Crunches', 'Core', 'Mat'),
(10,'Jump Rope', 'Cardio', 'Rope');

-- създаване на таблица Workout_exercises
create table workout_exercises
(
workout_id int not null,
FOREIGN KEY (workout_id)
REFERENCES workouts(workout_id),
exercise_id int not null,
FOREIGN KEY (exercise_id)
REFERENCES exercises(exercise_id),
sets int not null,
reps int not null
);
-- вмъкване на записи в Workout_exercises
INSERT INTO workout_exercises VALUES
(1, 1, 3, 15),
(1, 2, 3, 20),
(2, 5, 4, 10),
(2, 6, 3, 8),
(3, 2, 4, 15),
(3, 7, 3, 12),
(4, 10, 5, 60),
(5, 4, 4, 45),
(6, 1, 5, 20),
(10,3, 5, 5);

-- създаване на таблица Members_workouts
create table members_workouts
(
member_id int not null,
FOREIGN KEY (member_id)
REFERENCES members(members_id),
workout_id int not null,
FOREIGN KEY (workout_id)
REFERENCES workouts(workout_id),
start_hour TIME,
end_hour TIME
);
-- вмъкване на записи в Members_workouts
INSERT INTO members_workouts VALUES
(1, 1, '07:46:00', '09:00:00'),
(2, 2, '09:00', '10:23'),
(3, 3, '18:00', '19:00'),
(4, 4, '07:30', '08:58'),
(5, 5, '16:40', '18:00'),
(6, 6, '19:00', '20:23'),
(7, 7, '16:00', '17:17'),
(8, 8, '10:00', '11:39'),
(9, 9, '08:10', '09:30'),
(10,10,'18:17', '19:30');

-- създаване на таблица Subscriptions
create table subscriptions
(
subscription_id int auto_increment primary key,
member_id int not null,
FOREIGN KEY (member_id) REFERENCES members(members_id),
type varchar (100) not null,
price decimal (10,2) not null,
start_date date not null,
end_date date not null
);
-- вмъкване на записи в Subscriptions
INSERT INTO subscriptions VALUES
(1, 1, 'Monthly', 50.00, '2025-01-01', '2025-01-31'),
(2, 2, 'Monthly', 50.00, '2025-01-01', '2025-01-31'),
(3, 3, 'Annual', 500.00, '2025-01-01', '2025-12-31'),
(4, 4, 'Monthly', 50.00, '2025-02-01', '2025-02-28'),
(5, 5, 'Annual', 500.00, '2025-01-01', '2025-12-31'),
(6, 6, 'Monthly', 50.00, '2025-03-01', '2025-03-31'),
(7, 7, 'Monthly', 50.00, '2025-01-15', '2025-02-14'),
(8, 8, 'Annual', 500.00, '2025-01-01', '2025-12-31'),
(9, 9, 'Monthly', 50.00, '2025-02-01', '2025-02-28'),
(10,10,'Monthly', 50.00, '2026-01-01', '2026-01-31'),
(11, 11, 'Monthly', 50.00, '2025-03-01', '2025-03-31'),
(12, 12, 'Monthly', 50.00, '2025-01-27', '2025-02-27'),
(13, 13, 'Annual', 500.00, '2025-03-01', '2026-02-28'),
(14, 14, 'Monthly', 50.00, '2025-02-01', '2025-02-28'),
(15, 15, 'Annual', 500.00, '2026-01-01', '2026-12-31');

-- ЗАЯВКИ
-- 1. Всички членове
SELECT * FROM members;

-- 2. Всички треньори
SELECT * FROM trainers;

-- 3. Тренировки с треньорите им
SELECT w.name AS workout_name,
       w.difficulty_level,
       t.first_name,
       t.last_name
FROM workouts w
JOIN trainers t ON w.trainer_id = t.trainer_id;

-- 4. Упражнения за всяка тренировка
SELECT w.name AS workout_name,
       e.name AS exercise_name,
       we.sets,
       we.reps
FROM workout_exercises we
JOIN workouts w ON we.workout_id = w.workout_id
JOIN exercises e ON we.exercise_id = e.exercise_id;

-- 5. Упражнения по мускулна група
SELECT muscle_group, name as "exercise_name"
FROM exercises
ORDER BY muscle_group;

-- 6. Членове и техните тренировки
SELECT m.first_name,
       m.last_name,
       w.name AS workout_name
FROM members_workouts mw
JOIN members m ON mw.member_id = m.members_id
JOIN workouts w ON mw.workout_id = w.workout_id;

-- 7. Активни абонаменти
SELECT m.first_name,
       m.last_name,
       s.type,
       s.price
FROM subscriptions as s
JOIN members as m ON s.member_id = m.members_id;
-- BETWEEN s.start_date AND s.end_date;

-- 8. Брой тренировки на всеки треньор
SELECT t.first_name,
       t.last_name,
       COUNT(w.workout_id) AS total_workouts
FROM trainers t
LEFT JOIN workouts w ON t.trainer_id = w.trainer_id
GROUP BY t.trainer_id;

-- 9. Тренировки с ниво Beginner
SELECT name, difficulty_level
FROM workouts
WHERE difficulty_level = 'Easy';

-- 10. Брой тренировки на член на фитнеса
SELECT m.first_name,
       m.last_name,
       COUNT(mw.workout_id) AS workouts_count
FROM members m
JOIN members_workouts mw ON m.members_id = mw.member_id
GROUP BY m.members_id;

-- 11. Времетраене на тренировка
SELECT CONCAT(m.first_name, ' ', m.last_name) AS member_name,
    w.name AS workout_name,
    mw.start_hour,
    mw.end_hour,
    TIMEDIFF(mw.end_hour, mw.start_hour) AS duration
FROM members_workouts mw
JOIN members m ON mw.member_id = m.members_id
JOIN workouts w ON mw.workout_id = w.workout_id;

-- 12. Средно времетраене на тренировка
SELECT ROUND(AVG(TIME_TO_SEC(TIMEDIFF(end_hour, start_hour)) / 60), 2) AS avg_minutes
FROM members_workouts;

-- 13. Членове с активни абонаменти
SELECT m.first_name,
       m.last_name,
       s.type,
       s.start_date,
       s.end_date
FROM members m
JOIN subscriptions s ON m.members_id = s.member_id
WHERE CURDATE() BETWEEN s.start_date and s.end_date;

-- 14. Членове на фитнеса и тяхната възраст
SELECT 
    first_name,
    last_name,
    YEAR(CURDATE()) - YEAR(birth_date) AS age
FROM members;

-- 15. Членове с пол - мъж
SELECT first_name, last_name, gender
FROM members
WHERE gender = "Male";